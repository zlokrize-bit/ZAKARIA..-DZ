# Changelog

## 1.0.0

- First KATA LONI release (renamed from the VirtSpace prototype).
- Targets Android 16 (API 36), minSdk 26.
- App list with search, My space tabs, add / remove / launch.
- Artwork-based adaptive icon, Android 12+ splash screen, and in-app banner.
- English and Arabic (RTL) strings.
- Engine interface `VirtualCore` with a stub engine (no isolation).
- Gradle wrapper, GitHub Actions APK workflow, and documentation.
