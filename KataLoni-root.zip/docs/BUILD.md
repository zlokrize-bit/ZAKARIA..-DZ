# Building KATA LONI

## Requirements

| Tool | Version |
| --- | --- |
| JDK | 17 or newer |
| Android SDK | Platform 36 (Android 16) |
| Android Studio | A recent stable release (it bundles the JDK and SDK manager) |
| Gradle | Provided by `./gradlew` (8.14.3), nothing to install |

The first build needs internet access to download Gradle, the Android Gradle Plugin, and the AndroidX / Material libraries.

## Option 1: Android Studio

1. `File > Open` and choose the project folder.
2. Let Gradle sync. If Studio asks to install SDK Platform 36, accept.
3. `Build > Build Bundle(s) / APK(s) > Build APK(s)`.
4. Click "locate" in the notification to find the APK.

## Option 2: command line

```bash
export ANDROID_HOME=$HOME/Android/Sdk      # wherever your SDK lives
sdkmanager "platforms;android-36" "build-tools;36.0.0"

./gradlew assembleDebug      # app/build/outputs/apk/debug/app-debug.apk
./gradlew assembleRelease    # app/build/outputs/apk/release/app-release.apk
```

Windows: use `gradlew.bat`.

## Option 3: GitHub Actions

Push the project to a GitHub repository. The workflow `.github/workflows/build-apk.yml` runs on every push, builds both APKs, and uploads them as the `KataLoni-apk` artifact on the run page.

## Installing on a phone

Copy the APK to the phone, open it, and allow "Install unknown apps" for your file manager when Android asks.
The debug APK has the application id `com.kataloni.app.debug`, so it installs next to the release build.

## Signing

The release build is signed with the **debug key** (see `app/build.gradle.kts`) so the APK installs straight away.
That key is fine for personal use. Before publishing anywhere, create your own keystore and replace `signingConfig` in the `release` block. Keep the keystore out of git; `.gitignore` already excludes `*.jks` and `*.keystore`.

## Troubleshooting

- **"SDK location not found":** create `local.properties` with `sdk.dir=/path/to/Android/Sdk`, or set `ANDROID_HOME`.
- **"Failed to find target with hash string 'android-36'":** install Platform 36 with SDK Manager.
- **Gradle sync fails offline:** the first sync must be online.
- **Unsupported class file major version:** use JDK 17 or 21.
