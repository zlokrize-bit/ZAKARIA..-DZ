# Roadmap

## Phase 1: shell (done, version 1.0.0)

UI, saved My space list, themed artwork, build setup for Android 16, stub engine behind `VirtualCore`.

## Phase 2: app container engine

Run apps inside a sandbox the app controls, the way Parallel Space and VirtualApp-style projects do:

- Stub activities in KATA LONI that stand in for the target app's activities.
- Proxying of framework calls (`PackageManager`, `ActivityManager`) so the target app sees a virtual environment.
- Separate data directories per virtual app.

This needs deep knowledge of the Android framework and changes with every Android release, so the realistic path is building on an existing open-source container project after checking its license. Android 16 compatibility must be verified, not assumed.

## Phase 3: full virtual Android (VMOS style)

A complete Android system running inside the app, through Linux containers or QEMU:

- C/C++ and NDK work, plus an Android system image that boots on the phone.
- Root exists only **inside** the virtual device (a `su` binary in the guest image). The phone's real system is untouched.
- Performance work: graphics, audio, input, storage.

This is a very large project.

## Alternative: cloud virtual device

The virtual Android runs on a server and the app streams and controls it. Technically simpler, but it needs server infrastructure and running costs.

## Out of scope

Rooting the real device from a normal app. Android's security model does not allow it. Use the official bootloader unlock plus Magisk route on a device that supports it, at your own risk.
