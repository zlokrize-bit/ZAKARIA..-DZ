# Architecture

```
MainActivity ──► AppRepository      installed apps, saved My space list
      │
      └────────► VirtualCore        engine interface
                    └─ StubVirtualCore   today: plain launch, no isolation
```

## Pieces

- **`MainActivity`** owns the screen: banner, engine status line, search, the two tabs (installed apps / My space), and the About dialog. It loads the app list on a background thread in `onResume` and re-renders from an in-memory cache.
- **`AppAdapter`** renders one row per app. The primary button is "Add" or "Launch" depending on the tab; the secondary button is "Remove" and only shows in My space.
- **`AppRepository`** reads launchable apps through `PackageManager` and stores the My space package names in `SharedPreferences`. It excludes KATA LONI itself.
- **`VirtualCore`** is the only thing the UI knows about the engine: a name, an `isIsolated` flag, and `launch(context, packageName)`.

## Swapping in a real engine

1. Create a class that implements `VirtualCore` and returns `isIsolated = true` only when apps genuinely run inside the sandbox.
2. In `MainActivity`, replace `StubVirtualCore()` with your class.
3. The status line and About dialog pick up the new engine name and the isolation flag automatically.

## Android 16 behaviour handled

| Behaviour | Where |
| --- | --- |
| Edge-to-edge enforced (target 35+) | `enableEdgeToEdge()` + insets listener in `MainActivity` |
| Splash screen API | `Theme.KataLoni.Starting` + `installSplashScreen()` |
| Predictive back | `android:enableOnBackInvokedCallback="true"` |
| Package visibility | `<queries>` in the manifest |
| Large-screen resizing | No orientation or resizability locks are declared |
