<div dir="rtl">

<p align="center">
  <img src="docs/banner.jpg" alt="KATA LONI" width="360">
</p>

# KATA LONI

نموذج أولي لمساحة تطبيقات افتراضية على **أندرويد 16 (API 36)**، على فكرة VMOS وParallel Space.

English: [README.md](README.md)

## شنو يخدم دابا

- يعرض التطبيقات المثبتة في الجهاز مع بحث.
- تزيد أي تطبيق لـ **مساحتي** (القائمة تتحفظ محلياً).
- تشغّل التطبيقات من مساحتي.
- واجهة داكنة بستايل "ماتريكس"، أيقونة تكيفية، وشاشة بداية (Splash) لأندرويد 12 وما فوق، كلها مصنوعة من صورة KATA LONI.
- واجهة بالإنجليزية والعربية (من اليمين لليسار).

## مهم: شنو ما يديرش بعد

المحرك الحالي `StubVirtualCore` يشغّل التطبيقات بشكل عادي.
**ما كاين لا عزل ولا روت افتراضي بعد.** الشاشة تكتب "عزل حقيقي: لا" طول ما المحرك الوهمي مستعمل.
المحرك الحقيقي يتربط عبر واجهة `VirtualCore`. شوف [docs/ROADMAP.md](docs/ROADMAP.md).

KATA LONI ما يقدرش يعطي جوالك الحقيقي صلاحيات الروت. أندرويد ما يسمح لتطبيق عادي بهذا.

## كيفاش تخرج الـ APK

اختار طريقة وحدة:

1. **Android Studio:** افتح المجلد، استنى Gradle Sync، ثم `Build > Build Bundle(s) / APK(s) > Build APK(s)`.
2. **سطر الأوامر:** `./gradlew assembleDebug` (على ويندوز: `gradlew.bat assembleDebug`). الـ APK يطلع في `app/build/outputs/apk/debug/`.
3. **GitHub Actions:** ارفع المشروع لـ GitHub. ملف `.github/workflows/build-apk.yml` يبني الـ APK ويحطو في نتيجة التشغيل باسم `KataLoni-apk`.

التفاصيل الكاملة: [docs/BUILD.md](docs/BUILD.md).

## ملاحظات أندرويد 16

- `compileSdk` و`targetSdk` = 36، و`minSdk` = 26 (أندرويد 8.0).
- الشاشة الكاملة (edge-to-edge) إجبارية من أندرويد 15، لذلك الواجهة تتعامل مع الـ insets بنفسها.
- الرجوع التنبؤي (Predictive back) مفعّل في الـ manifest.
- التطبيق يستعمل `<queries>` باش يشوف التطبيقات، بلا ما يحتاج `QUERY_ALL_PACKAGES`.

</div>
