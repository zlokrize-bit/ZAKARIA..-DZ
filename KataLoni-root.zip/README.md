<p align="center">
  <img src="docs/banner.jpg" alt="KATA LONI" width="360">
</p>

# KATA LONI

A virtual app space prototype for **Android 16 (API 36)**, in the spirit of VMOS and Parallel Space.

العربية: [README.ar.md](README.ar.md)

## What works today

- Lists the apps installed on the device, with search.
- Adds apps to **My space** (the list is saved locally).
- Launches apps from My space.
- Dark "matrix" theme, adaptive launcher icon, and Android 12+ splash screen, all built from the KATA LONI artwork.
- English and Arabic (right-to-left) interface.

## Important: what it does not do yet

The current engine, `StubVirtualCore`, launches apps normally.
**There is no isolation and no virtual root yet.** The screen says so ("Real isolation: No") as long as the stub engine is in use.
A real engine plugs in through the `VirtualCore` interface. See [docs/ROADMAP.md](docs/ROADMAP.md).

KATA LONI cannot give your real phone root access. Android does not allow a normal app to do that.

## Build the APK

Pick one:

1. **Android Studio:** open this folder, wait for Gradle sync, then `Build > Build Bundle(s) / APK(s) > Build APK(s)`.
2. **Command line:** `./gradlew assembleDebug` (Windows: `gradlew.bat assembleDebug`). The APK lands in `app/build/outputs/apk/debug/`.
3. **GitHub Actions:** push the project to GitHub. The workflow in `.github/workflows/build-apk.yml` builds the APKs and attaches them to the run as `KataLoni-apk`.

Full details: [docs/BUILD.md](docs/BUILD.md).

## Project layout

```
app/src/main/java/com/kataloni/app/
  MainActivity.kt        screen: banner, search, tabs, list, about dialog
  AppAdapter.kt          list rows
  core/VirtualCore.kt    engine interface + the stub engine
  data/AppRepository.kt  installed apps + saved My space list
app/src/main/res/
  drawable-nodpi/        banner and launcher artwork
  mipmap-anydpi-v26/     adaptive launcher icon
  values/ values-ar/     colors, theme, English and Arabic strings
docs/                    build guide, architecture, roadmap, artwork
```

## Android 16 notes

- `compileSdk` and `targetSdk` are 36; `minSdk` is 26 (Android 8.0).
- Edge-to-edge is enforced on Android 15+ for apps targeting API 35+, so the screen handles window insets itself.
- Predictive back is enabled in the manifest.
- The app declares a `<queries>` entry to see launchable apps, so it does not need `QUERY_ALL_PACKAGES`.

## License

MIT, see [LICENSE](LICENSE). The artwork in `docs/banner.jpg` and `res/drawable-nodpi/` is yours; change the license if you need different terms.
