package com.kataloni.app

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.kataloni.app.data.AppInfo
import com.kataloni.app.databinding.ItemAppBinding

class AppAdapter(
    private val onPrimary: (AppInfo) -> Unit,
    private val onSecondary: (AppInfo) -> Unit
) : RecyclerView.Adapter<AppAdapter.Holder>() {

    private var items: List<AppInfo> = emptyList()
    private var inSpace = false

    fun submit(newItems: List<AppInfo>, inSpace: Boolean) {
        items = newItems
        this.inSpace = inSpace
        notifyDataSetChanged()
    }

    class Holder(val binding: ItemAppBinding) : RecyclerView.ViewHolder(binding.root)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): Holder =
        Holder(ItemAppBinding.inflate(LayoutInflater.from(parent.context), parent, false))

    override fun onBindViewHolder(holder: Holder, position: Int) {
        val app = items[position]
        val b = holder.binding
        b.icon.setImageDrawable(app.icon)
        b.label.text = app.label
        b.pkg.text = app.packageName

        if (inSpace) {
            b.primary.setText(R.string.action_launch)
            b.secondary.setText(R.string.action_remove)
            b.secondary.visibility = View.VISIBLE
        } else {
            b.primary.setText(R.string.action_add)
            b.secondary.visibility = View.GONE
        }
        b.primary.setOnClickListener { onPrimary(app) }
        b.secondary.setOnClickListener { onSecondary(app) }
    }

    override fun getItemCount() = items.size
}
