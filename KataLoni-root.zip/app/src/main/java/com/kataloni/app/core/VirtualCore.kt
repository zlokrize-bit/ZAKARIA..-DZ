package com.kataloni.app.core

import android.content.Context
import android.content.Intent

/**
 * The seam between the UI and the virtualization engine.
 *
 * To turn KATA LONI into a real virtual space, implement this interface with a real
 * engine and swap it in MainActivity. Nothing else in the app needs to change.
 */
interface VirtualCore {
    val engineName: String

    /** True only when launched apps really run isolated from the host system. */
    val isIsolated: Boolean

    fun launch(context: Context, packageName: String): Boolean
}

/**
 * Placeholder engine: launches the app normally.
 * NO isolation and NO virtual root. It exists so the UI and data flow can be built
 * and tested before a real engine exists.
 */
class StubVirtualCore : VirtualCore {
    override val engineName = "Stub"
    override val isIsolated = false

    override fun launch(context: Context, packageName: String): Boolean {
        val intent = context.packageManager.getLaunchIntentForPackage(packageName)
            ?: return false
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        return try {
            context.startActivity(intent)
            true
        } catch (e: Exception) {
            false
        }
    }
}
