package com.kataloni.app.data

import android.content.Context
import android.content.Intent
import android.graphics.drawable.Drawable

data class AppInfo(
    val label: String,
    val packageName: String,
    val icon: Drawable
)

class AppRepository(private val context: Context) {

    private val prefs = context.getSharedPreferences("space", Context.MODE_PRIVATE)

    /** All apps that have a launcher entry, except this app itself. Call off the main thread. */
    fun installedApps(): List<AppInfo> {
        val pm = context.packageManager
        val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        return pm.queryIntentActivities(intent, 0)
            .map { it.activityInfo.applicationInfo }
            .distinctBy { it.packageName }
            .filter { it.packageName != context.packageName }
            .map { AppInfo(it.loadLabel(pm).toString(), it.packageName, it.loadIcon(pm)) }
            .sortedBy { it.label.lowercase() }
    }

    fun spacePackages(): Set<String> =
        prefs.getStringSet(KEY, emptySet())?.toSet() ?: emptySet()

    fun addToSpace(packageName: String) {
        prefs.edit().putStringSet(KEY, spacePackages() + packageName).apply()
    }

    fun removeFromSpace(packageName: String) {
        prefs.edit().putStringSet(KEY, spacePackages() - packageName).apply()
    }

    companion object {
        private const val KEY = "space_packages"
    }
}
