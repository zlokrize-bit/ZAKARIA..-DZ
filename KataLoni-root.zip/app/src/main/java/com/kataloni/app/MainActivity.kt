package com.kataloni.app

import android.graphics.Color
import android.os.Bundle
import android.widget.Toast
import androidx.activity.SystemBarStyle
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.splashscreen.SplashScreen.Companion.installSplashScreen
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.isVisible
import androidx.core.widget.doAfterTextChanged
import androidx.recyclerview.widget.LinearLayoutManager
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.kataloni.app.core.StubVirtualCore
import com.kataloni.app.core.VirtualCore
import com.kataloni.app.data.AppInfo
import com.kataloni.app.data.AppRepository
import com.kataloni.app.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private lateinit var repo: AppRepository
    private lateinit var adapter: AppAdapter

    // Swap this for a real engine implementation later.
    private val core: VirtualCore = StubVirtualCore()

    private var allApps: List<AppInfo> = emptyList()
    private var showSpace = false
    private var query = ""

    override fun onCreate(savedInstanceState: Bundle?) {
        installSplashScreen()
        super.onCreate(savedInstanceState)

        // Android 15+/16 enforce edge-to-edge for apps targeting API 35+, so handle insets ourselves.
        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.dark(Color.TRANSPARENT),
            navigationBarStyle = SystemBarStyle.dark(Color.TRANSPARENT)
        )
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
        ViewCompat.setOnApplyWindowInsetsListener(binding.root) { view, insets ->
            val bars = insets.getInsets(
                WindowInsetsCompat.Type.systemBars() or WindowInsetsCompat.Type.displayCutout()
            )
            view.setPadding(bars.left, bars.top, bars.right, bars.bottom)
            insets
        }

        repo = AppRepository(this)

        adapter = AppAdapter(
            onPrimary = { app -> if (showSpace) launch(app) else addToSpace(app) },
            onSecondary = { app -> removeFromSpace(app) }
        )
        binding.list.layoutManager = LinearLayoutManager(this)
        binding.list.adapter = adapter

        binding.engineInfo.text = getString(
            R.string.engine_info,
            core.engineName,
            yesNo(core.isIsolated)
        )

        binding.search.doAfterTextChanged {
            query = it?.toString().orEmpty()
            render()
        }

        binding.toggle.addOnButtonCheckedListener { _, checkedId, isChecked ->
            if (isChecked) {
                showSpace = checkedId == R.id.btnSpace
                render()
            }
        }
        binding.toggle.check(R.id.btnInstalled)

        binding.aboutButton.setOnClickListener { showAbout() }
    }

    override fun onResume() {
        super.onResume()
        loadApps()
    }

    private fun loadApps() {
        Thread {
            val apps = repo.installedApps()
            runOnUiThread {
                if (isFinishing || isDestroyed) return@runOnUiThread
                allApps = apps
                render()
            }
        }.start()
    }

    private fun render() {
        val inSpace = repo.spacePackages()
        val q = query.trim().lowercase()
        val list = allApps
            .filter { (it.packageName in inSpace) == showSpace }
            .filter {
                q.isEmpty() || it.label.lowercase().contains(q) || it.packageName.contains(q)
            }
        adapter.submit(list, showSpace)
        binding.empty.isVisible = list.isEmpty()
        binding.counter.text = getString(R.string.apps_count, list.size)
    }

    private fun addToSpace(app: AppInfo) {
        repo.addToSpace(app.packageName)
        Toast.makeText(this, getString(R.string.added, app.label), Toast.LENGTH_SHORT).show()
        render()
    }

    private fun removeFromSpace(app: AppInfo) {
        repo.removeFromSpace(app.packageName)
        render()
    }

    private fun launch(app: AppInfo) {
        if (!core.launch(this, app.packageName)) {
            Toast.makeText(this, R.string.launch_failed, Toast.LENGTH_SHORT).show()
        }
    }

    private fun showAbout() {
        val version = try {
            packageManager.getPackageInfo(packageName, 0).versionName ?: ""
        } catch (e: Exception) {
            ""
        }
        MaterialAlertDialogBuilder(this)
            .setTitle(R.string.app_name)
            .setMessage(
                getString(R.string.about_message, version, core.engineName, yesNo(core.isIsolated))
            )
            .setPositiveButton(R.string.action_ok, null)
            .show()
    }

    private fun yesNo(value: Boolean) = getString(if (value) R.string.yes else R.string.no)
}
