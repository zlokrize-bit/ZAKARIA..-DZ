# KATA LONI ProGuard / R8 rules.
# Minification is currently disabled in app/build.gradle.kts, so nothing is required yet.
# Keep the engine interface stable once a real engine is plugged in:
-keep interface com.kataloni.app.core.VirtualCore { *; }
